import { useCallback, useEffect, useRef, useState } from "react";

/**
 * The Web Speech API's SpeechRecognition interface isn't part of
 * TypeScript's standard DOM lib -- it's non-standard/vendor-prefixed,
 * well-supported in Chrome/Edge, historically unreliable or absent in
 * Firefox. These are minimal hand-written types for just the surface this
 * hook actually uses, not a full polyfill of the spec.
 */
interface SpeechRecognitionAlternative {
  transcript: string;
}
interface SpeechRecognitionResultList {
  length: number;
  [index: number]: { [index: number]: SpeechRecognitionAlternative };
}
interface SpeechRecognitionEvent extends Event {
  results: SpeechRecognitionResultList;
}
interface SpeechRecognitionErrorEvent extends Event {
  error: string;
}
interface SpeechRecognitionInstance extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start: () => void;
  stop: () => void;
  onresult: ((event: SpeechRecognitionEvent) => void) | null;
  onerror: ((event: SpeechRecognitionErrorEvent) => void) | null;
  onend: (() => void) | null;
}

declare global {
  interface Window {
    SpeechRecognition?: new () => SpeechRecognitionInstance;
    webkitSpeechRecognition?: new () => SpeechRecognitionInstance;
  }
}

interface UseSpeechRecognitionOptions {
  /** Called once with the final transcript when a single utterance ends. */
  onResult: (transcript: string) => void;
}

/**
 * Single-utterance voice input (click, speak, get text) -- not continuous
 * dictation. Scoped deliberately small: browser-native only, no cloud
 * transcription, no voice commands, just filling one text field by voice
 * instead of typing.
 */
export function useSpeechRecognition({ onResult }: UseSpeechRecognitionOptions) {
  const [isListening, setIsListening] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const recognitionRef = useRef<SpeechRecognitionInstance | null>(null);

  const isSupported =
    typeof window !== "undefined" && !!(window.SpeechRecognition || window.webkitSpeechRecognition);

  const start = useCallback(() => {
    if (!isSupported) {
      setError("Voice input isn't supported in this browser (try Chrome or Edge).");
      return;
    }
    const SpeechRecognitionCtor = window.SpeechRecognition ?? window.webkitSpeechRecognition;
    if (!SpeechRecognitionCtor) return;

    const recognition = new SpeechRecognitionCtor();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = "en-US";

    recognition.onresult = (event) => {
      // continuous=false means a single utterance -- exactly one result,
      // whose top alternative ([0]) is the recognized transcript.
      const lastIndex = event.results.length - 1;
      const transcript = event.results[lastIndex][0].transcript;
      onResult(transcript);
    };
    recognition.onerror = (event) => {
      setError(
        event.error === "not-allowed"
          ? "Microphone access denied — check your browser's site permissions."
          : `Voice input error: ${event.error}`
      );
      setIsListening(false);
    };
    recognition.onend = () => setIsListening(false);

    recognitionRef.current = recognition;
    setError(null);
    setIsListening(true);
    recognition.start();
  }, [isSupported, onResult]);

  const stop = useCallback(() => {
    recognitionRef.current?.stop();
    setIsListening(false);
  }, []);

  useEffect(() => {
    return () => {
      recognitionRef.current?.stop();
    };
  }, []);

  return { isSupported, isListening, error, start, stop };
}
