type Status = "running" | "done" | "error" | "stale" | null | undefined;

interface StatusBadgeProps {
  status: Status;
  runningLabel?: string;
}

/**
 * One shared component for both ingestion status and report status -- the
 * Streamlit version had this same running/done/error/stale logic
 * duplicated across two nearly-identical if/elif blocks (the Data
 * Scrapping page and the sidebar Reports panel). Deliberately
 * de-duplicated here rather than replicated twice.
 */
export function StatusBadge({ status, runningLabel }: StatusBadgeProps) {
  if (!status) {
    return (
      <span className="inline-block px-3 py-1 rounded-pill text-xs font-semibold bg-surface-alt text-text-muted">
        Not started
      </span>
    );
  }

  const variants: Record<NonNullable<Status>, string> = {
    running: "bg-primary/15 text-[#1F8F6E]",
    done: "bg-primary/15 text-[#1F8F6E]",
    error: "bg-red-100 text-red-700",
    stale: "bg-amber-100 text-amber-700",
  };

  const labels: Record<NonNullable<Status>, string> = {
    running: runningLabel ?? "Running",
    done: "Done",
    error: "Error",
    stale: "Stale",
  };

  return (
    <span className={`inline-block px-3 py-1 rounded-pill text-xs font-semibold ${variants[status]}`}>
      {labels[status]}
    </span>
  );
}
