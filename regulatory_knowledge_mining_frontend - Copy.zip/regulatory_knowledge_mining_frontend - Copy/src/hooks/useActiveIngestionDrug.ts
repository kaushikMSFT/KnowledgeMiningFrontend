import { useQuery } from "@tanstack/react-query";

import { ingestionApi } from "../api/client";

/**
 * Polls which drug (if any) currently holds the system-wide ingestion
 * lock. Cheap regardless of table size -- ONE request, not one per row.
 * See DashboardPage.tsx for how this drives per-row status invalidation.
 */
export function useActiveIngestionDrug(intervalMs = 4000) {
  return useQuery({
    queryKey: ["ingest-active"],
    queryFn: () => ingestionApi.active(),
    refetchInterval: intervalMs,
  });
}