import type { ButtonHTMLAttributes } from "react";

type ButtonVariant = "primary" | "secondary";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
}

/**
 * Direct port of the Streamlit theme's button rules (THEME_CSS,
 * [data-testid="baseButton-primary"/"secondary"]): true pill shape
 * (radius = height/2), navy fill for primary, white/bordered for
 * secondary. Same visual result, no CSS data-testid targeting needed --
 * this is a real component now, not a global selector hoping to catch
 * the right Streamlit-generated element.
 */
export function Button({ variant = "primary", className = "", ...props }: ButtonProps) {
  const base =
    "rounded-pill font-semibold px-5 py-2 transition-all duration-150 disabled:opacity-50 disabled:cursor-not-allowed";
  const variantClasses =
    variant === "primary"
      ? "bg-secondary text-white shadow-soft hover:brightness-110"
      : "bg-white text-secondary border border-border-light hover:border-secondary";

  return <button className={`${base} ${variantClasses} ${className}`} {...props} />;
}
