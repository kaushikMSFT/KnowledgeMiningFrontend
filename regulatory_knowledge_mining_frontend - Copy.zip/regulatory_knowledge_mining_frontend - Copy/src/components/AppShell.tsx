import type { ReactNode } from "react";
import { NavLink } from "react-router-dom";

const NAV_ITEMS = [
  { to: "/ingest", label: "Drug Ingestion" },
  { to: "/query", label: "Query Engine" },
  { to: "/dashboard", label: "Drug Explorer" },
  { to: "/molecule", label: "Molecule 360" },
];

interface AppShellProps {
  children: ReactNode;
  /** Page-specific sidebar content (session tools, report panel, etc.) --
   * each page owns this, rather than one shared sidebar component
   * branching internally on which workspace is active (see the plan,
   * Section 3: "a genuine navigational improvement worth doing"). */
  sidebarExtra?: ReactNode;
}

export function AppShell({ children, sidebarExtra }: AppShellProps) {
  return (
    <div className="min-h-screen bg-page-canvas">
      <header className="px-8 py-5">
        <h1 className="text-2xl font-semibold text-secondary tracking-tight">
          Regulatory Knowledge Mining
        </h1>
      </header>

      <div className="flex gap-6 px-8 pb-12">
        <nav className="w-[22%] min-w-[220px]">
          <div className="rounded-xl bg-secondary shadow-soft p-3">
            <p className="text-xs font-semibold uppercase tracking-wide text-white/60 px-3 pt-2 pb-3">
              Workspace
            </p>
            <ul className="flex flex-col gap-0.5">
              {NAV_ITEMS.map((item) => (
                <li key={item.to}>
                  <NavLink
                    to={item.to}
                    className={({ isActive }) =>
                      `block rounded-lg px-3 py-2.5 text-sm transition-colors duration-150 ${
                        isActive
                          ? "bg-white/15 text-white font-medium"
                          : "text-white/80 hover:bg-white/8"
                      }`
                    }
                  >
                    {item.label}
                  </NavLink>
                </li>
              ))}
            </ul>
          </div>

          {sidebarExtra && <div className="mt-4">{sidebarExtra}</div>}
        </nav>

        <main className="flex-1 min-w-0">{children}</main>
      </div>
    </div>
  );
}
