import { useState } from "react";
import { useSearchParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";

import { molecule360Api } from "../api/client";
import { useDebouncedValue } from "../hooks/useDebouncedValue";
import { TabBar } from "../components/TabBar";
import { DataTable, buildDynamicColumns } from "../components/DataTable";
import { FieldsList } from "../components/FieldsList";

const TABS = [
  { id: "orange-book", label: "Orange Book" },
  { id: "drugs-at-fda", label: "Drugs@FDA" },
  { id: "dissolution", label: "Dissolution" },
  { id: "psg", label: "PSG" },
  { id: "dailymed", label: "DailyMed" },
];

export function Molecule360Page() {
  // Accepts brand/ingredient as URL query params -- same pattern
  // IngestPage already navigates with on "View in Molecule 360 →", so
  // deep-linking works without any extra wiring on that end.
  const [searchParams] = useSearchParams();
  const [brand, setBrand] = useState(searchParams.get("brand") ?? "");
  const [ingredient, setIngredient] = useState(searchParams.get("ingredient") ?? "");
  const [activeTab, setActiveTab] = useState("orange-book");

  // Debounced -- the /full endpoint does a live Drugs@FDA fetch server-side,
  // not just a local lookup, so re-querying on every keystroke would be
  // wasteful the same way un-debounced dashboard filters would be.
  const debouncedBrand = useDebouncedValue(brand, 500);
  const debouncedIngredient = useDebouncedValue(ingredient, 500);
  const molecule = (debouncedIngredient || debouncedBrand).trim();

  const query = useQuery({
    queryKey: ["molecule360-full", debouncedBrand, debouncedIngredient],
    queryFn: () =>
      molecule360Api.full(debouncedBrand || undefined, debouncedIngredient || undefined),
    enabled: !!molecule,
  });

  const data = query.data;

  return (
    <div>
      <h2 className="text-xl font-semibold text-secondary mb-1">Molecule 360°</h2>
      <p className="text-sm text-text-muted mb-6">
        Consolidated regulatory view for one molecule, across all five ingested sources.
        Fields with no data show <strong>Not identified</strong> — never blank, never
        inferred.
      </p>

      <div className="bg-white rounded-xl border border-border-light shadow-soft p-4 mb-6 flex gap-4">
        <div className="flex-1">
          <label className="block text-sm text-text-dark mb-1">
            Proprietary / Brand Name (RLD)
          </label>
          <input
            className="w-full rounded-lg border border-border-light px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary"
            placeholder="e.g. Plavix"
            value={brand}
            onChange={(e) => setBrand(e.target.value)}
          />
        </div>
        <div className="flex-1">
          <label className="block text-sm text-text-dark mb-1">Active Ingredient</label>
          <input
            className="w-full rounded-lg border border-border-light px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary"
            placeholder="e.g. Clopidogrel Bisulfate"
            value={ingredient}
            onChange={(e) => setIngredient(e.target.value)}
          />
        </div>
      </div>

      {!molecule && (
        <p className="text-sm text-text-muted">
          Enter a brand name or active ingredient to see its consolidated regulatory
          data.
        </p>
      )}

      {molecule && query.isLoading && <p className="text-sm text-text-muted">Loading…</p>}

      {data && (
        <>
          <TabBar tabs={TABS} activeTab={activeTab} onChange={setActiveTab} />

          {activeTab === "orange-book" &&
            (data.orange_book.error ? (
              <p className="text-sm text-amber-700">{data.orange_book.error}</p>
            ) : data.orange_book.count === 0 ? (
              <p className="text-sm text-text-muted">
                No Orange Book records found for {molecule}.
              </p>
            ) : (
              <>
                <p className="text-sm text-text-muted mb-2">
                  {data.orange_book.count} product/patent/exclusivity row(s)
                </p>
                <DataTable
                  data={data.orange_book.rows}
                  columns={buildDynamicColumns(data.orange_book.rows)}
                />
              </>
            ))}

          {activeTab === "drugs-at-fda" &&
            (data.drugs_at_fda.error ? (
              <p className="text-sm text-amber-700">{data.drugs_at_fda.error}</p>
            ) : (
              <>
                <p className="text-sm text-text-dark mb-4">
                  <strong>
                    {data.drugs_at_fda.header["Application Type"] ?? "Not identified"}{" "}
                    {data.drugs_at_fda.header["Application Number"] ?? ""}
                  </strong>{" "}
                  — {data.drugs_at_fda.header["Applicant"] ?? "Not identified"}
                </p>

                <h4 className="text-sm font-semibold text-secondary mb-2">Products</h4>
                {data.drugs_at_fda.products.length > 0 ? (
                  <DataTable
                    data={data.drugs_at_fda.products}
                    columns={buildDynamicColumns(data.drugs_at_fda.products)}
                  />
                ) : (
                  <p className="text-sm text-text-muted mb-4">
                    No product table found on this application's page.
                  </p>
                )}

                <h4 className="text-sm font-semibold text-secondary mt-6 mb-2">
                  Submission History
                </h4>
                {data.drugs_at_fda.submissions.length > 0 ? (
                  <DataTable
                    data={data.drugs_at_fda.submissions}
                    columns={buildDynamicColumns(data.drugs_at_fda.submissions, [
                      "Linked Documents",
                    ])}
                  />
                ) : (
                  <p className="text-sm text-text-muted">
                    No submission history found on this application's page.
                  </p>
                )}
              </>
            ))}

          {activeTab === "dissolution" &&
            (data.dissolution.error ? (
              <p className="text-sm text-amber-700">{data.dissolution.error}</p>
            ) : data.dissolution.count === 0 ? (
              <p className="text-sm text-text-muted">
                No dissolution method found for {molecule}.
              </p>
            ) : (
              <>
                <p className="text-sm text-text-muted mb-2">
                  {data.dissolution.count} dissolution method row(s)
                </p>
                <DataTable
                  data={data.dissolution.rows}
                  columns={buildDynamicColumns(data.dissolution.rows)}
                />
              </>
            ))}

          {activeTab === "psg" &&
            (data.psg.error ? (
              <p className="text-sm text-text-muted">{data.psg.error}</p>
            ) : (
              <>
                <p className="text-sm text-text-muted mb-2">
                  Extracted from <strong>{data.psg.source_pdf}</strong> — verbatim text
                  extraction, not an AI summary.
                </p>
                {data.psg.note && (
                  <p className="text-xs text-text-muted mb-2">{data.psg.note}</p>
                )}
                <FieldsList fields={data.psg.fields} />
              </>
            ))}

          {activeTab === "dailymed" &&
            (data.dailymed.error ? (
              <p className="text-sm text-text-muted">{data.dailymed.error}</p>
            ) : (
              <>
                <p className="text-sm text-text-muted mb-2">
                  Extracted from <strong>{data.dailymed.source_pdf}</strong> — verbatim
                  text extraction, not an AI summary. Active/inactive ingredient list is
                  intentionally omitted here — see the Orange Book tab for a reliable
                  ingredient name.
                </p>
                <FieldsList fields={data.dailymed.fields} />
              </>
            ))}
        </>
      )}
    </div>
  );
}
