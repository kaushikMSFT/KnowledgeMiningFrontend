/**
 * Hand-written to match api/schemas.py exactly, field by field.
 *
 * This should be REGENERATED once the FastAPI server is actually running,
 * via `npm run codegen:api-types` (openapi-typescript pointed at the live
 * /openapi.json) -- that will catch any drift between this file and the
 * real backend automatically. Hand-writing this now is a deliberate
 * stopgap: the backend can't be started in this environment (no network
 * to install fastapi/pydantic here), so this file was matched by reading
 * schemas.py directly rather than introspecting a running server.
 */

// ---------------------------------------------------------------------------
// Ingestion
// ---------------------------------------------------------------------------

export interface IngestionStartRequest {
  drug_name: string;
  brand_name?: string | null;
  active_ingredient?: string | null;
  delete_vectors_first?: boolean;
}

export interface IngestionStartResponse {
  started: boolean;
  reason: "started" | "already_running" | "another_drug_running";
  active_drug?: string | null;
}

export type IngestionStatus = "running" | "done" | "error" | "stale" | null;

export interface IngestionStatusResponse {
  status: IngestionStatus;
  step?: string | null;
  heartbeat_at?: string | null;
  started_at?: string | null;
  total_chunks?: number | null;
  orange_book_message?: string | null;
  orange_book_ok?: boolean | null;
  message?: string | null;
  progress_percent?: number | null;
}

export interface ActiveIngestionResponse {
  active_drug?: string | null;
}

// ---------------------------------------------------------------------------
// Molecule 360
// ---------------------------------------------------------------------------

export interface OrangeBookGridResponse {
  rows: Record<string, unknown>[];
  count: number;
  error?: string | null;
}

export interface DissolutionGridResponse {
  rows: Record<string, unknown>[];
  count: number;
  error?: string | null;
}

export interface DrugsAtFdaGridResponse {
  header: Record<string, string>;
  products: Record<string, unknown>[];
  submissions: Record<string, unknown>[];
  error?: string | null;
  source_url?: string | null;
}

/** Shared shape for both PSG and DailyMed grids. */
export interface FieldsGridResponse {
  fields: Record<string, string>;
  error?: string | null;
  source_pdf?: string | null;
  note?: string | null;
}

export interface Molecule360Response {
  orange_book: OrangeBookGridResponse;
  dissolution: DissolutionGridResponse;
  drugs_at_fda: DrugsAtFdaGridResponse;
  psg: FieldsGridResponse;
  dailymed: FieldsGridResponse;
}

// ---------------------------------------------------------------------------
// Metadata Dashboard
// ---------------------------------------------------------------------------

export interface MetadataColumnInfo {
  name: string;
  type?: string | null;
  hidden: boolean;
}

export interface MetadataQueryRequest {
  filters: Record<string, string>;
  sort_by?: string | null;
  sort_dir: "asc" | "desc";
  page: number;
  page_size: number;
}

export interface MetadataQueryResponse {
  items: Record<string, unknown>[];
  total: number;
  page: number;
  page_size: number;
  total_pages: number;
}

export interface MetadataRefreshResponse {
  row_count: number;
  source_path?: string | null;
  duration_seconds?: number | null;
  refreshed_at?: string | null;
  message?: string | null;
}

export interface LastRefreshResponse {
  refreshed_at?: string | null;
  row_count?: number | null;
  source_path?: string | null;
  duration_seconds?: number | null;
}

// ---------------------------------------------------------------------------
// Query Engine
// ---------------------------------------------------------------------------

export interface QueryRequest {
  drug_name: string;
  question: string;
  top_k?: number;
  chat_model?: string | null;
}

export interface SourceEntry {
  source: string;
  filename: string;
}

export interface VerifiedCitation {
  source_index: number;
  claimed_snippet: string;
  verified: boolean;
  reference: string;
  chunk_text: string;
}

export interface QueryResponse {
  answer: string;
  sources: SourceEntry[];
  verified_citations: VerifiedCitation[];
  model?: string | null;
}

// ---------------------------------------------------------------------------
// Reports
// ---------------------------------------------------------------------------

export interface ReportStartRequest {
  drug_name: string;
  force_refresh?: boolean;
  top_k?: number;
  chat_model?: string | null;
  pace_seconds?: number;
}

export interface ReportStartResponse {
  started: boolean;
  reason: "started" | "already_running" | "already_cached";
}

export type ReportStatus = "running" | "done" | "error" | "stale" | null;

export interface ReportStatusResponse {
  status: ReportStatus;
  question_num?: number | null;
  total_questions?: number | null;
  section_title?: string | null;
  question_text?: string | null;
  heartbeat_at?: string | null;
  report_pdf_path?: string | null;
  pdf_error?: string | null;
  message?: string | null;
}
