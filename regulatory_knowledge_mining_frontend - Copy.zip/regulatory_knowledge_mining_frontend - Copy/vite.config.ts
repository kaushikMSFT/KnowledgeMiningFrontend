import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Proxying /api during dev means the frontend never needs a hardcoded
// absolute URL to the FastAPI server, and avoids relying on the backend's
// permissive CORS config (which the FastAPI layer's README explicitly
// flags as "local dev only, tighten before real deployment"). In
// production, whatever serves the built frontend should proxy /api the
// same way (e.g. an nginx location block), so this same relative-path
// convention keeps working without a rebuild.
export default defineConfig({
  plugins: [react()],
  server: {
    proxy: {
      "/api": {
        target: "http://localhost:8050",
        changeOrigin: true,
      },
    },
  },
});