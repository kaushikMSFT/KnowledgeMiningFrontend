import { useQuery, type UseQueryResult } from "@tanstack/react-query";

interface Pollable {
  status?: string | null;
}

/**
 * Wraps TanStack Query's refetchInterval with the same "keep polling only
 * while running" policy Streamlit's st.rerun()-on-interaction pattern
 * achieved manually. Used identically for ingestion status and report
 * status -- both APIs return a `status` field with the same four possible
 * values ("running" | "done" | "error" | "stale" | null).
 *
 * intervalMs default (2500ms) is deliberately a bit slower than the
 * cross-drug lock check (see useActiveIngestionDrug) -- job status doesn't
 * need to be as snappy as "is a different row's button clickable right
 * now."
 */
export function usePollingStatus<T extends Pollable>(
  queryKey: unknown[],
  queryFn: () => Promise<T>,
  options?: { intervalMs?: number; enabled?: boolean }
): UseQueryResult<T> {
  const intervalMs = options?.intervalMs ?? 2500;

  return useQuery({
    queryKey,
    queryFn,
    enabled: options?.enabled ?? true,
    refetchInterval: (query) => {
      const status = query.state.data?.status;
      return status === "running" ? intervalMs : false;
    },
  });
}
