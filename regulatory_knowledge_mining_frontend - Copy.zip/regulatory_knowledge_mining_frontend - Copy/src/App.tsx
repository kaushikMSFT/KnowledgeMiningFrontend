import { Navigate, Route, Routes } from "react-router-dom";
 
import { AppShell } from "./components/AppShell";
import { IngestPage } from "./pages/IngestPage";
import { QueryPage } from "./pages/QueryPage";
import { DashboardPage } from "./pages/DashboardPage";
import { Molecule360Page } from "./pages/Molecule360Page";
 
export function App() {
  return (
    <AppShell>
      <Routes>
        <Route path="/" element={<Navigate to="/ingest" replace />} />
        <Route path="/ingest" element={<IngestPage />} />
        <Route path="/query" element={<QueryPage />} />
        <Route path="/dashboard" element={<DashboardPage />} />
        <Route path="/molecule" element={<Molecule360Page />} />
      </Routes>
    </AppShell>
  );
}
 