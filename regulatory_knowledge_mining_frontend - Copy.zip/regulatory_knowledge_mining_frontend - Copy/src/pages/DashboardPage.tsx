import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import type { ColumnDef, SortingState } from "@tanstack/react-table";

import { metadataApi, ApiError } from "../api/client";
import type { MetadataQueryResponse } from "../api/types";
import { useActiveIngestionDrug } from "../hooks/useActiveIngestionDrug";
import { KnowledgeMineButton } from "../components/KnowledgeMineButton";
import { FilterPanel } from "../components/FilterPanel";
import { Button } from "../components/Button";
import { DataTable } from "../components/DataTable";


const PAGE_SIZE = 15;

// A curated "headline" subset for the visible columns, same reasoning as
// the Streamlit version's row_cols_spec: with ~27 real Orange Book
// columns, showing every one at once (even with horizontal scroll) is
// harder to scan than a focused set. Filters (left panel) still cover
// every column -- this only affects which columns render in the grid.
const HEADLINE_COLUMNS = [
  { key: "drug_name", label: "Drug Name" },
  { key: "ingredient", label: "Ingredient" },
  { key: "applicant", label: "Applicant" },
  { key: "appl_no", label: "Appl. No." },
  { key: "approval_date", label: "Approval Date" },
  { key: "marketing_status", label: "Status" },
];

export function DashboardPage() {
  const queryClient = useQueryClient();
  const [filters, setFilters] = useState<Record<string, string>>({});
  const [sorting, setSorting] = useState<SortingState>([]);
  const [page, setPage] = useState(1);

  const columnsQuery = useQuery({
    queryKey: ["metadata-columns"],
    queryFn: () => metadataApi.columns(),
  });

  const activeDrugQuery = useActiveIngestionDrug();
  const activeDrug = activeDrugQuery.data?.active_drug ?? null;

  // Whenever the system-wide active drug changes (a job started,
  // finished, or switched to a different drug), broadly invalidate every
  // row's status query. TanStack Query only refetches queries that are
  // actually mounted right now, so this stays cheap even with 200 rows
  // on the page -- it does NOT mean 200 new requests fire, only the ones
  // currently being observed.
  useEffect(() => {
    queryClient.invalidateQueries({ queryKey: ["ingest-status"] });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [activeDrug]);

  // Any filter/sort change resets to page 1, matching the Streamlit
  // version's behavior so results stay coherent.
  useEffect(() => {
    setPage(1);
  }, [filters, sorting]);

  const sortBy = sorting[0]?.id;
  const sortDir = sorting[0] ? (sorting[0].desc ? "desc" : "asc") : "asc";

  const tableQuery = useQuery<MetadataQueryResponse, ApiError>({
    queryKey: ["metadata-query", filters, sortBy, sortDir, page],
    queryFn: () =>
      metadataApi.query({
        filters,
        sort_by: sortBy ?? null,
        sort_dir: sortDir,
        page,
        page_size: PAGE_SIZE,
      }),
    enabled: !!columnsQuery.data,
  });

  const refreshMutation = useMutation({
    mutationFn: () => metadataApi.refresh(),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["metadata-columns"] });
      queryClient.invalidateQueries({ queryKey: ["metadata-query"] });
    },
  });

  const columns: ColumnDef<Record<string, unknown>, any>[] = [
    ...HEADLINE_COLUMNS.map(
      (c): ColumnDef<Record<string, unknown>, any> => ({
        id: c.key,
        header: c.label,
        accessorFn: (row) => row[c.key],
        cell: (info) => {
          const val = info.getValue();
          return val === null || val === undefined || val === "" ? "—" : String(val);
        },
      })
    ),
    {
      id: "action",
      header: "Action",
      enableSorting: false,
      cell: ({ row }) => (
        <KnowledgeMineButton
          brandName={String(row.original["drug_name"] ?? "")}
          ingredient={String(row.original["ingredient"] ?? "")}
          activeDrug={activeDrug}
        />
      ),
    },
  ];

  // 409 from the backend means no metadata has been loaded yet -- the
  // real API semantics (see api/routers/metadata.py), not a generic
  // failure. Show the same "prompt a refresh" guidance the Streamlit
  // version showed for this exact case.
  const needsInitialRefresh =
    tableQuery.error instanceof ApiError && tableQuery.error.status === 409;

  const totalPages = tableQuery.data?.total_pages ?? 1;

  return (
    <div>
      <h2 className="text-xl font-semibold text-secondary mb-1">Metadata Dashboard</h2>
      <p className="text-sm text-text-muted mb-6">
        All approved-drug metadata from the Orange Book aggregate (products + patents +
        exclusivities), not filtered to a single drug.
      </p>

      <div className="flex gap-6">
        <div className="w-[260px] shrink-0">
          {columnsQuery.data && (
            <FilterPanel columns={columnsQuery.data} onFiltersChange={setFilters} />
          )}
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center justify-between mb-4">
            <div>
              {tableQuery.data && (
                <p className="text-sm text-text-muted">
                  {tableQuery.data.total.toLocaleString()} matching rows — page{" "}
                  {tableQuery.data.page} of {totalPages}
                </p>
              )}
            </div>
            <Button
              variant="primary"
              disabled={refreshMutation.isPending}
              onClick={() => refreshMutation.mutate()}
            >
              {refreshMutation.isPending ? "Refreshing…" : "Refresh from source"}
            </Button>
          </div>

          {needsInitialRefresh && (
            <div className="bg-white rounded-xl border border-border-light shadow-soft p-8 text-center">
              <p className="text-sm text-text-muted mb-4">
                No metadata loaded yet. Click <strong>Refresh from source</strong> to load
                all approved-drug records — this takes roughly 15-25 seconds against the
                real Orange Book aggregate.
              </p>
            </div>
          )}

          {tableQuery.data && (
            <>
              <DataTable
                data={tableQuery.data.items}
                columns={columns}
                sorting={sorting}
                onSortingChange={setSorting}
                pinnedRight={["action"]}
                emptyMessage="No rows match the current filters."
              />

              <div className="flex items-center justify-center gap-4 mt-4">
                <Button
                  variant="secondary"
                  disabled={page <= 1}
                  onClick={() => setPage((p) => p - 1)}
                >
                  ◀ Prev
                </Button>
                <span className="text-sm text-text-muted">
                  Page {page} of {totalPages}
                </span>
                <Button
                  variant="secondary"
                  disabled={page >= totalPages}
                  onClick={() => setPage((p) => p + 1)}
                >
                  Next ▶
                </Button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}