import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";

import { queryApi } from "../api/client";
import type { VerifiedCitation } from "../api/types";
import { useSpeechRecognition } from "../hooks/useSpeechRecognition";
import { Button } from "../components/Button";
import { CitationPanel } from "../components/CitationPanel";

interface QueryTurn {
  question: string;
  answer: string;
  verifiedCitations: VerifiedCitation[];
  timestamp: string;
}

const DEFAULT_QUESTION =
  "Summarize exclusivity and patent information for this drug, dissolution media if present.";

/**
 * Deliberately lightweight, NOT a general markdown renderer -- handles
 * exactly the known output format from rag_pipeline.py's system prompt
 * ("Respond with markdown bullet points, each factual point as '- ...'").
 * If the backend's answer format ever expands beyond bullet points, a
 * real markdown library (e.g. react-markdown) would be the right call
 * instead of extending this.
 */
function AnswerMarkdown({ text }: { text: string }) {
  const lines = text
    .split("\n")
    .map((l) => l.trim())
    .filter((l) => l !== "");

  return (
    <div className="space-y-1.5 text-sm text-text-dark">
      {lines.map((line, i) =>
        line.startsWith("- ") ? (
          <div key={i} className="flex gap-2">
            <span className="text-primary">•</span>
            <span>{line.slice(2)}</span>
          </div>
        ) : (
          <p key={i}>{line}</p>
        )
      )}
    </div>
  );
}

export function QueryPage() {
  const [selectedDrug, setSelectedDrug] = useState("");
  const [question, setQuestion] = useState(DEFAULT_QUESTION);
  // Session history is client-side only for this pass -- a deliberate
  // scope decision, not an oversight. The technical design doc flags
  // real disk-backed persistence (GET/POST /api/query/sessions, wrapping
  // the backend's existing _save_session_file/_load_session_file logic)
  // as the recommended follow-up, since the Streamlit version's history
  // does survive a reload today and this doesn't yet.
  const [turns, setTurns] = useState<QueryTurn[]>([]);
  const [error, setError] = useState<string | null>(null);

  const speech = useSpeechRecognition({
    onResult: (transcript) => setQuestion(transcript),
  });

  const availableQuery = useQuery({
    queryKey: ["query-available"],
    queryFn: () => queryApi.available(),
  });

  const runMutation = useMutation({
    mutationFn: () => queryApi.run({ drug_name: selectedDrug, question }),
    onSuccess: (result) => {
      setError(null);
      setTurns((prev) => [
        {
          question,
          answer: result.answer,
          verifiedCitations: result.verified_citations,
          timestamp: new Date().toISOString(),
        },
        ...prev,
      ]);
    },
    onError: (err) => {
      setError(err instanceof Error ? err.message : "Something went wrong.");
    },
  });

  const products = availableQuery.data ?? [];
  const canQuery = !!selectedDrug && question.trim() !== "" && !runMutation.isPending;

  return (
    <div className="max-w-3xl">
      <h2 className="text-xl font-semibold text-secondary mb-1">Query Engine</h2>
      <p className="text-sm text-text-muted mb-6">
        Ask natural-language questions about an ingested drug, with grounded, verifiable
        citations.
      </p>

      <div className="bg-white rounded-xl border border-border-light shadow-soft p-6 space-y-4 mb-6">
        <div>
          <label className="block text-sm text-text-dark mb-1">Drug</label>
          {products.length === 0 ? (
            <p className="text-sm text-text-muted">
              No ingested drugs yet — ingest one first on the Data Scrapping &amp;
              Embedding page.
            </p>
          ) : (
            <select
              className="w-full rounded-lg border border-border-light px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary"
              value={selectedDrug}
              onChange={(e) => setSelectedDrug(e.target.value)}
            >
              <option value="">Select a drug…</option>
              {products.map((p) => (
                <option key={p} value={p}>
                  {p}
                </option>
              ))}
            </select>
          )}
        </div>

        <div>
          <div className="flex items-center justify-between mb-1">
            <label className="block text-sm text-text-dark">Question</label>
            {speech.isSupported && (
              <button
                type="button"
                onClick={speech.isListening ? speech.stop : speech.start}
                className={`flex items-center gap-1.5 rounded-pill px-3 py-1 text-xs font-medium border transition-colors ${
                  speech.isListening
                    ? "bg-red-50 border-red-200 text-red-700"
                    : "bg-white border-border-light text-secondary hover:border-secondary"
                }`}
              >
                <span>{speech.isListening ? "●" : "🎤"}</span>
                {speech.isListening ? "Listening… (click to stop)" : "Speak your question"}
              </button>
            )}
          </div>
          <textarea
            className="w-full rounded-lg border border-border-light px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary"
            rows={4}
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
          />
          {speech.error && <p className="text-xs text-amber-700 mt-1">{speech.error}</p>}
        </div>

        {error && <p className="text-sm text-red-700">{error}</p>}

        <Button variant="primary" disabled={!canQuery} onClick={() => runMutation.mutate()}>
          {runMutation.isPending ? "Retrieving + generating…" : "Run Query"}
        </Button>
      </div>

      {turns.length > 0 && (
        <div>
          <h3 className="text-sm font-semibold text-secondary mb-3">Session history</h3>
          <div className="space-y-6">
            {turns.map((turn, i) => (
              <div
                key={i}
                className="bg-white rounded-xl border border-border-light shadow-soft p-5"
              >
                <p className="text-sm font-semibold text-text-dark mb-2">
                  Q: {turn.question}
                </p>
                <AnswerMarkdown text={turn.answer} />
                <CitationPanel verifiedCitations={turn.verifiedCitations} />
                <p className="text-xs text-text-muted mt-3">{turn.timestamp}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
