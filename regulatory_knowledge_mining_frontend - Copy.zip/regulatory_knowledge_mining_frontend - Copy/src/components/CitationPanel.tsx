import type { VerifiedCitation } from "../api/types";

interface CitationPanelProps {
  verifiedCitations: VerifiedCitation[];
}

/**
 * Direct port of the Streamlit _render_citation_verification() panel --
 * shows ONLY the pages the model actually cited, each with the exact
 * quoted phrase, split into two collapsible sections. This component does
 * ZERO verification logic itself -- the snippet-matching/grounding already
 * happened entirely server-side (citation_verification.py); this is pure
 * rendering, same as the Streamlit version's own comment states.
 *
 * Uses native <details>/<summary> for the collapsed-by-default behavior
 * (matches st.expander's default), no extra dependency needed.
 */
export function CitationPanel({ verifiedCitations }: CitationPanelProps) {
  if (verifiedCitations.length === 0) return null;

  const verified = verifiedCitations.filter((c) => c.verified);
  const unverified = verifiedCitations.filter((c) => !c.verified);

  return (
    <div className="mt-3 space-y-2">
      <details className="bg-white rounded-xl border border-border-light shadow-soft">
        <summary className="cursor-pointer px-4 py-2.5 text-sm font-medium text-secondary select-none">
          Pages used ({verified.length})
        </summary>
        <div className="px-4 pb-3 pt-1">
          {verified.length === 0 ? (
            <p className="text-xs text-text-muted">
              No citations in this answer could be verified against the retrieved
              sources.
            </p>
          ) : (
            verified.map((c, i) => (
              <div
                key={i}
                className={i > 0 ? "border-t border-border-light pt-2 mt-2" : ""}
              >
                <p className="text-sm font-semibold text-text-dark">{c.reference}</p>
                <p className="text-sm text-text-muted italic">“{c.claimed_snippet}”</p>
              </div>
            ))
          )}
        </div>
      </details>

      {unverified.length > 0 && (
        <details className="bg-white rounded-xl border border-amber-200 shadow-soft">
          <summary className="cursor-pointer px-4 py-2.5 text-sm font-medium text-amber-700 select-none">
            ⚠️ Claimed but could not verify ({unverified.length})
          </summary>
          <div className="px-4 pb-3 pt-1">
            <p className="text-xs text-text-muted mb-2">
              The model cited these sources, but the exact phrase it quoted was not
              found in that source's actual text — treat with caution.
            </p>
            {unverified.map((c, i) => (
              <div
                key={i}
                className={i > 0 ? "border-t border-border-light pt-2 mt-2" : ""}
              >
                <p className="text-sm font-semibold text-text-dark">{c.reference}</p>
                <p className="text-sm text-text-muted italic">“{c.claimed_snippet}”</p>
              </div>
            ))}
          </div>
        </details>
      )}
    </div>
  );
}
