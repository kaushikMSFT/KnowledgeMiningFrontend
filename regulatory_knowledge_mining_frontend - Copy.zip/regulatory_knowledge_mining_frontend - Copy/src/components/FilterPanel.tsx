import { useEffect, useState } from "react";

import type { MetadataColumnInfo } from "../api/types";

import { Button } from "./Button";
import { useDebouncedValue } from "../hooks/UseDebouncedValue";

interface FilterPanelProps {
  columns: MetadataColumnInfo[];
  onFiltersChange: (filters: Record<string, string>) => void;
}

/**
 * Debounced (400ms) per-field text inputs -- avoids firing a query on
 * every keystroke, which the Streamlit version's rerun-per-interaction
 * model didn't need to worry about the same way.
 */
export function FilterPanel({ columns, onFiltersChange }: FilterPanelProps) {
  const [values, setValues] = useState<Record<string, string>>({});
  const debounced = useDebouncedValue(values, 400);

  useEffect(() => {
    const nonEmpty = Object.fromEntries(
      Object.entries(debounced).filter(([, v]) => v.trim() !== "")
    );
    onFiltersChange(nonEmpty);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [debounced]);

  const visibleColumns = columns.filter((c) => !c.hidden);

  return (
    <div className="bg-white rounded-xl border border-border-light shadow-soft p-4">
      <h3 className="text-sm font-semibold text-secondary mb-3">Filters</h3>
      <div className="space-y-3 max-h-[60vh] overflow-y-auto pr-1">
        {visibleColumns.map((col) => (
          <div key={col.name}>
            <label className="block text-xs text-text-muted mb-1">
              {col.name.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase())}
            </label>
            <input
              className="w-full rounded-lg border border-border-light px-2.5 py-1.5 text-sm focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary"
              value={values[col.name] ?? ""}
              onChange={(e) => setValues((prev) => ({ ...prev, [col.name]: e.target.value }))}
            />
          </div>
        ))}
      </div>
      <Button
        variant="secondary"
        className="w-full mt-4 text-sm"
        onClick={() => setValues({})}
      >
        Clear filters
      </Button>
    </div>
  );
}