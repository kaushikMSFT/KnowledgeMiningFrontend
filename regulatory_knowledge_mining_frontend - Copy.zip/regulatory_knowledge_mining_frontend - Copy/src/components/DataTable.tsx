import {
  useReactTable,
  getCoreRowModel,
  getSortedRowModel,
  flexRender,
  type ColumnDef,
  type SortingState,
} from "@tanstack/react-table";

interface DataTableProps<T> {
  data: T[];
  columns: ColumnDef<T, any>[];
  sorting?: SortingState;
  onSortingChange?: (sorting: SortingState) => void;
  /** Column IDs pinned to the right edge -- e.g. the Metadata Dashboard's
   * Action column, which must never scroll away. This is the direct
   * replacement for the Streamlit version's HTML-table-plus-separate-
   * button-column redesign; TanStack Table solves this as a native
   * feature, no custom scroll-region engineering needed. */
  pinnedRight?: string[];
  emptyMessage?: string;
}

/**
 * Reusable data grid. Used by the Metadata Dashboard (with pinnedRight
 * for the Action column and a custom cell renderer for hover-reveal
 * buttons) and, later, by Molecule 360's Orange Book/Dissolution tabs
 * (plain, no pinning needed there).
 */
export function DataTable<T>({
  data,
  columns,
  sorting,
  onSortingChange,
  pinnedRight = [],
  emptyMessage = "No rows.",
}: DataTableProps<T>) {
  const table = useReactTable({
    data,
    columns,
    state: {
      sorting: sorting ?? [],
    },
    onSortingChange: onSortingChange
      ? (updater) => {
          const next = typeof updater === "function" ? updater(sorting ?? []) : updater;
          onSortingChange(next);
        }
      : undefined,
    initialState: {
      columnPinning: { right: pinnedRight },
    },
    getCoreRowModel: getCoreRowModel(),
    getSortedRowModel: getSortedRowModel(),
  });

  if (data.length === 0) {
    return <p className="text-sm text-text-muted py-8 text-center">{emptyMessage}</p>;
  }

  const pinnedCellClasses =
    "sticky right-0 z-10 shadow-[-4px_0_6px_-2px_rgba(0,0,0,0.06)]";

  return (
    <div className="overflow-x-auto rounded-xl border border-border-light shadow-soft bg-white">
      <table className="w-full text-sm border-collapse">
        <thead>
          {table.getHeaderGroups().map((headerGroup) => (
            <tr key={headerGroup.id} className="bg-surface-alt">
              {headerGroup.headers.map((header) => {
                const isPinned = header.column.getIsPinned();
                const sortState = header.column.getIsSorted();
                return (
                  <th
                    key={header.id}
                    onClick={header.column.getToggleSortingHandler()}
                    className={`px-4 py-3 text-left font-semibold text-text-muted uppercase text-xs tracking-wide whitespace-nowrap ${
                      header.column.getCanSort() ? "cursor-pointer select-none" : ""
                    } ${isPinned ? `${pinnedCellClasses} bg-surface-alt` : ""}`}
                  >
                    {flexRender(header.column.columnDef.header, header.getContext())}
                    {sortState === "asc" && " ▲"}
                    {sortState === "desc" && " ▼"}
                  </th>
                );
              })}
            </tr>
          ))}
        </thead>
        <tbody>
          {table.getRowModel().rows.map((row) => (
            <tr key={row.id} className="group border-t border-border-light hover:bg-surface-alt/60">
              {row.getVisibleCells().map((cell) => {
                const isPinned = cell.column.getIsPinned();
                return (
                  <td
                    key={cell.id}
                    className={`px-4 py-3 whitespace-nowrap ${
                      isPinned ? `${pinnedCellClasses} bg-white group-hover:bg-surface-alt` : ""
                    }`}
                  >
                    {flexRender(cell.column.columnDef.cell, cell.getContext())}
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

/**
 * Builds column definitions dynamically from whatever keys the data
 * actually has. Used by Molecule 360's tabs (Orange Book, Dissolution,
 * Drugs@FDA products/submissions), which -- unlike the Metadata
 * Dashboard's deliberately curated headline subset -- show the full row
 * shape for one already-filtered molecule, where every returned column is
 * relevant.
 */
export function buildDynamicColumns(
  rows: Record<string, unknown>[],
  excludeKeys: string[] = []
): ColumnDef<Record<string, unknown>, any>[] {
  if (rows.length === 0) return [];
  const keys = Object.keys(rows[0]).filter((k) => !excludeKeys.includes(k));
  return keys.map((key) => ({
    id: key,
    header: key.replace(/_/g, " ").replace(/\b\w/g, (c) => c.toUpperCase()),
    accessorFn: (row) => row[key],
    cell: (info) => {
      const val = info.getValue();
      return val === null || val === undefined || val === "" ? "—" : String(val);
    },
  }));
}
