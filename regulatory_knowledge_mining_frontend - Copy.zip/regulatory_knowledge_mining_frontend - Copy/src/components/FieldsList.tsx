interface FieldsListProps {
  fields: Record<string, string>;
}

/**
 * Used identically by both PSG and DailyMed tabs -- both return the exact
 * same FieldsGridResponse shape. Renders whatever comes through directly;
 * does NOT invent its own empty-state text -- the backend already sends
 * the literal string "Not identified" for missing fields (a deliberate
 * product decision made server-side), so this component just displays it.
 */
export function FieldsList({ fields }: FieldsListProps) {
  const entries = Object.entries(fields);

  if (entries.length === 0) {
    return <p className="text-sm text-text-muted py-6 text-center">No fields available.</p>;
  }

  return (
    <div className="bg-white rounded-xl border border-border-light shadow-soft divide-y divide-border-light">
      {entries.map(([key, value]) => (
        <div key={key} className="flex gap-4 px-4 py-3">
          <div className="w-56 shrink-0 text-sm font-medium text-text-muted">{key}</div>
          <div className="text-sm text-text-dark flex-1">{value}</div>
        </div>
      ))}
    </div>
  );
}
