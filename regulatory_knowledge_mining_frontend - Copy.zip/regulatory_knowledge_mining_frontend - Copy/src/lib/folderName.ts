/**
 * Matches Python's _folder_name_from_search() exactly (app.py, and
 * duplicated in the FastAPI routers for the same reason -- app.py isn't
 * an importable module). Same brand-or-ingredient, strip (R)/(TM) logic.
 * If this drifts from the Python original, ingestion/lookup folder names
 * will mismatch between the frontend and backend -- keep these in sync
 * deliberately, not by copy-paste luck.
 */
export function folderNameFromSearch(brand: string, ingredient: string): string {
  const b = brand.trim();
  const i = ingredient.trim();
  const raw = b || i;
  if (!raw) return "";
  return raw.replace(/[®™]+/g, "").trim();
}
