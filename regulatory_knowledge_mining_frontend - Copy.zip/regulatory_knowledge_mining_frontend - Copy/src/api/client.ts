import type {
  ActiveIngestionResponse,
  IngestionStartRequest,
  IngestionStartResponse,
  IngestionStatusResponse,
  LastRefreshResponse,
  MetadataColumnInfo,
  MetadataQueryRequest,
  MetadataQueryResponse,
  MetadataRefreshResponse,
  Molecule360Response,
  QueryRequest,
  QueryResponse,
  ReportStartRequest,
  ReportStartResponse,
  ReportStatusResponse,
} from "./types";

/**
 * Every path here is relative ("/api/...") -- resolved against the current
 * origin. In dev, vite.config.ts proxies /api to the FastAPI server on
 * :8000. In production, whatever serves this built app should proxy /api
 * the same way. This is deliberate: no hardcoded absolute backend URL
 * anywhere in the app.
 */

export class ApiError extends Error {
  status: number;
  constructor(status: number, detail: string) {
    super(detail);
    this.status = status;
    this.name = "ApiError";
  }
}

async function request<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(path, {
    headers: { "Content-Type": "application/json" },
    ...init,
  });
  if (!res.ok) {
    // FastAPI's HTTPException responses are always {"detail": "..."} --
    // e.g. the 409 from /api/metadata/query when no data has been
    // refreshed yet, or the 404 from /api/query when a drug isn't
    // ingested. Surfacing `detail` directly means the UI can show the
    // exact same guidance message the backend already wrote, rather than
    // a generic "request failed."
    let detail = res.statusText;
    try {
      const body = await res.json();
      if (typeof body?.detail === "string") detail = body.detail;
    } catch {
      // Response wasn't JSON -- fall back to statusText, don't throw a
      // second error while handling the first.
    }
    throw new ApiError(res.status, detail);
  }
  // Endpoints with no meaningful body (rare here) would need a guard;
  // every real endpoint in this API returns JSON.
  return res.json() as Promise<T>;
}

function toQueryString(params: Record<string, string | undefined>): string {
  const usable = Object.entries(params).filter(
    (entry): entry is [string, string] => entry[1] !== undefined && entry[1] !== ""
  );
  if (usable.length === 0) return "";
  return "?" + new URLSearchParams(usable).toString();
}

// ---------------------------------------------------------------------------
// Ingestion
// ---------------------------------------------------------------------------

export const ingestionApi = {
  start: (body: IngestionStartRequest) =>
    request<IngestionStartResponse>("/api/ingest/start", {
      method: "POST",
      body: JSON.stringify(body),
    }),

  status: (drugName: string) =>
    request<IngestionStatusResponse>(`/api/ingest/status/${encodeURIComponent(drugName)}`),

  active: () => request<ActiveIngestionResponse>("/api/ingest/active"),
};

// ---------------------------------------------------------------------------
// Molecule 360
// ---------------------------------------------------------------------------

export const molecule360Api = {
  full: (brandName?: string, activeIngredient?: string) =>
    request<Molecule360Response>(
      `/api/molecule360/full${toQueryString({
        brand_name: brandName,
        active_ingredient: activeIngredient,
      })}`
    ),
};

// ---------------------------------------------------------------------------
// Metadata Dashboard
// ---------------------------------------------------------------------------

export const metadataApi = {
  columns: () => request<MetadataColumnInfo[]>("/api/metadata/columns"),

  lastRefresh: () => request<LastRefreshResponse>("/api/metadata/last-refresh"),

  refresh: () => request<MetadataRefreshResponse>("/api/metadata/refresh", { method: "POST" }),

  query: (body: MetadataQueryRequest) =>
    request<MetadataQueryResponse>("/api/metadata/query", {
      method: "POST",
      body: JSON.stringify(body),
    }),
};

// ---------------------------------------------------------------------------
// Query Engine
// ---------------------------------------------------------------------------

export const queryApi = {
  available: () => request<string[]>("/api/query/available"),

  run: (body: QueryRequest) =>
    request<QueryResponse>("/api/query", {
      method: "POST",
      body: JSON.stringify(body),
    }),
};

// ---------------------------------------------------------------------------
// Reports
// ---------------------------------------------------------------------------

export const reportsApi = {
  start: (body: ReportStartRequest) =>
    request<ReportStartResponse>("/api/reports/start", {
      method: "POST",
      body: JSON.stringify(body),
    }),

  status: (drugName: string) =>
    request<ReportStatusResponse>(`/api/reports/status/${encodeURIComponent(drugName)}`),

  downloadUrl: (drugName: string) => `/api/reports/download/${encodeURIComponent(drugName)}`,
};
