/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        // Sampled directly from the real Nagarro Leave Manager screenshot --
        // see technical_design_document.md, Section 8. These are not
        // exploratory; they are fixed reference values.
        primary: "#47D7AC", // teal -- stat numbers, logo mark, positive accents
        secondary: "#13294B", // navy -- sidebar, primary buttons, selected states
        "accent-purple": "#2E008B", // used SPARINGLY -- label text only, never interactive
        "page-canvas": "#F7F8FA",
        "surface-alt": "#EFF1F4",
        "border-light": "#DCDCDC",
        "text-dark": "#141414",
        "text-muted": "#5B6472",
      },
      fontFamily: {
        sans: ["IBM Plex Sans", "sans-serif"],
        mono: ["IBM Plex Mono", "monospace"],
      },
      borderRadius: {
        pill: "9999px",
      },
      boxShadow: {
        // Soft elevation from the reference -- not a heavy drop shadow.
        soft: "0 1px 2px rgba(19,41,75,0.04), 0 2px 10px rgba(19,41,75,0.06)",
      },
    },
  },
  plugins: [],
};
