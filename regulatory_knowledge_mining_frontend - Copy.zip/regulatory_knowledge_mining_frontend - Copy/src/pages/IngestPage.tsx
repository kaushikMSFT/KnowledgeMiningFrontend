import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";

import { ingestionApi, ApiError } from "../api/client";
import { folderNameFromSearch } from "../lib/folderName";
import { usePollingStatus } from "../hooks/usePollingStatus";
import { Button } from "../components/Button";
import { StatusBadge } from "../components/StatusBadge";

export function IngestPage() {
  const [brand, setBrand] = useState("");
  const [ingredient, setIngredient] = useState("");
  const [formError, setFormError] = useState<string | null>(null);
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const drugName = folderNameFromSearch(brand, ingredient);

  const statusQuery = usePollingStatus(
    ["ingest-status", drugName],
    () => ingestionApi.status(drugName),
    { enabled: !!drugName }
  );

  const startMutation = useMutation({
    mutationFn: (deleteVectorsFirst: boolean) =>
      ingestionApi.start({
        drug_name: drugName,
        brand_name: brand || undefined,
        active_ingredient: ingredient || undefined,
        delete_vectors_first: deleteVectorsFirst,
      }),
    onSuccess: (result) => {
      if (!result.started) {
        setFormError(
          result.reason === "another_drug_running"
            ? `An ingestion job is already running for ${result.active_drug} — please wait for it to finish.`
            : "An ingestion job is already running for this drug."
        );
      } else {
        setFormError(null);
      }
      queryClient.invalidateQueries({ queryKey: ["ingest-status", drugName] });
    },
    onError: (err) => {
      setFormError(err instanceof ApiError ? err.message : "Something went wrong.");
    },
  });

  const status = statusQuery.data?.status ?? null;
  const hasManifest = status === "done";

  return (
    <div className="max-w-3xl">
      <h2 className="text-xl font-semibold text-secondary mb-6">Data Ingestion</h2>

      <div className="bg-white rounded-xl shadow-soft border border-border-light p-6 space-y-4">
        <div>
          <label className="block text-sm text-text-dark mb-1">Proprietary / Brand Name (RLD)</label>
          <input
            className="w-full rounded-lg border border-border-light px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary"
            placeholder="e.g. Plavix"
            value={brand}
            onChange={(e) => setBrand(e.target.value)}
          />
        </div>
        <div>
          <label className="block text-sm text-text-dark mb-1">Active Ingredient</label>
          <input
            className="w-full rounded-lg border border-border-light px-3 py-2 focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary"
            placeholder="e.g. Clopidogrel Bisulfate"
            value={ingredient}
            onChange={(e) => setIngredient(e.target.value)}
          />
        </div>

        {status === "running" && (
          <p className="text-sm text-text-muted">
            <StatusBadge status="running" /> {statusQuery.data?.step ?? "Working…"}
          </p>
        )}
        {status === "stale" && (
          <p className="text-sm text-amber-700">
            Ingestion looks abandoned (no update in 15+ minutes) — safe to retry.
          </p>
        )}
        {status === "error" && (
          <p className="text-sm text-red-700">
            Last ingestion failed: {statusQuery.data?.message ?? "Unknown error"}
          </p>
        )}
        {status === "done" && (
          <p className="text-sm text-text-muted">
            <StatusBadge status="done" /> Last ingestion complete
            {statusQuery.data?.total_chunks != null && ` — ${statusQuery.data.total_chunks} chunks indexed`}.
          </p>
        )}
        {formError && <p className="text-sm text-red-700">{formError}</p>}

        <div className="flex items-center gap-3 pt-2">
          <Button
            variant="primary"
            disabled={!drugName || status === "running" || startMutation.isPending}
            onClick={() => startMutation.mutate(false)}
          >
            Ingest Data
          </Button>
          <Button
            variant="secondary"
            disabled={!drugName || status === "running" || startMutation.isPending}
            onClick={() => startMutation.mutate(true)}
          >
            Rebuild Data
          </Button>
          {hasManifest && (
            <Button
              variant="secondary"
              onClick={() =>
                navigate(
                  `/molecule?brand=${encodeURIComponent(brand)}&ingredient=${encodeURIComponent(ingredient)}`
                )
              }
            >
              View in Molecule 360 →
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
