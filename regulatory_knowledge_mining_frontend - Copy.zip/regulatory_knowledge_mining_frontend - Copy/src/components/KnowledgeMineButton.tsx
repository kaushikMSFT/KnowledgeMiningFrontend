import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";

import { ingestionApi } from "../api/client";
import { folderNameFromSearch } from "../lib/folderName";

interface KnowledgeMineButtonProps {
  brandName: string;
  ingredient: string;
  /** From useActiveIngestionDrug() -- which drug (if any) currently holds
   * the system-wide lock. Used only to decide whether THIS row should
   * keep polling for live progress; the actual block/allow decision is
   * always the server's, via the mutation's response -- same as the
   * original Streamlit version, which let the click happen and showed
   * the "already running" warning from the backend's answer, not a
   * client-side guess made in advance. */
  activeDrug: string | null | undefined;
}

const buttonBase =
  "opacity-0 group-hover:opacity-100 transition-opacity rounded-pill px-3 py-1 text-xs font-medium disabled:opacity-40 disabled:cursor-not-allowed";

export function KnowledgeMineButton({ brandName, ingredient, activeDrug }: KnowledgeMineButtonProps) {
  const folderName = folderNameFromSearch(brandName, ingredient);
  const isActiveRow = !!folderName && activeDrug === folderName;
  const [warning, setWarning] = useState<string | null>(null);
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  // One-time fetch on mount (no polling) for every row -- just enough to
  // know initial state (not-started vs done). Only the row matching the
  // global active drug polls continuously, for live progress -- see the
  // design note in DashboardPage.tsx for why blind per-row polling at
  // table scale (up to 200 rows) would be wasteful.
  const statusQuery = useQuery({
    queryKey: ["ingest-status", folderName],
    queryFn: () => ingestionApi.status(folderName),
    enabled: !!folderName,
    refetchInterval: isActiveRow ? 2500 : false,
  });

  const startMutation = useMutation({
    mutationFn: () =>
      ingestionApi.start({
        drug_name: folderName,
        brand_name: brandName || undefined,
        active_ingredient: ingredient || undefined,
      }),
    onSuccess: (result) => {
      if (!result.started) {
        setWarning(
          result.reason === "another_drug_running"
            ? `An ingestion job is already running for ${result.active_drug} — please wait for it to finish.`
            : "An ingestion job is already running for this drug."
        );
      } else {
        setWarning(null);
      }
      queryClient.invalidateQueries({ queryKey: ["ingest-status", folderName] });
      queryClient.invalidateQueries({ queryKey: ["ingest-active"] });
    },
    onError: () => setWarning("Something went wrong starting ingestion."),
  });

  if (!folderName) {
    return <span className="text-xs text-text-muted">—</span>;
  }

  const status = statusQuery.data?.status ?? null;

  if (status === "running") {
    const pct = statusQuery.data?.progress_percent ?? 0;
    return (
      <button
        onClick={() => statusQuery.refetch()}
        className={`${buttonBase} border border-border-light bg-white text-secondary hover:border-secondary`}
      >
        Refresh ({pct}%)
      </button>
    );
  }

  if (status === "done") {
    return (
      <button
        onClick={() =>
          navigate(
            `/molecule?brand=${encodeURIComponent(brandName)}&ingredient=${encodeURIComponent(ingredient)}`
          )
        }
        className={`${buttonBase} bg-secondary text-white hover:brightness-110`}
      >
        Go to Molecule 360 →
      </button>
    );
  }

  // Not started, or a previous attempt errored/went stale -- same "Mine
  // Knowledge" entry point either way, matching the original design.
  return (
    <div className="relative">
      <button
        disabled={startMutation.isPending}
        onClick={() => startMutation.mutate()}
        className={`${buttonBase} border border-border-light bg-white text-secondary hover:border-secondary`}
      >
        Mine Knowledge
      </button>
      {warning && (
        <p className="absolute right-0 top-full mt-1 w-52 text-xs text-amber-700 bg-white border border-border-light rounded-lg p-2 shadow-soft z-20">
          {warning}
        </p>
      )}
    </div>
  );
}